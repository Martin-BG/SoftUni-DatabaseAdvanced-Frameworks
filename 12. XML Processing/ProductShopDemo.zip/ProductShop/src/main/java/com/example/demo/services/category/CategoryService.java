package com.example.demo.services.category;

public interface CategoryService {
}