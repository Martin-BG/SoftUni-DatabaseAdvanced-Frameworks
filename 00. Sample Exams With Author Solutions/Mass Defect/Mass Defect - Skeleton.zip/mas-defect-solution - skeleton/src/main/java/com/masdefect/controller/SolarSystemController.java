package com.masdefect.controller;

import org.springframework.stereotype.Controller;

@Controller
public class SolarSystemController {

    public String importDataFromJSON(String fileContent){
      //impl
        return null;
    }
}
