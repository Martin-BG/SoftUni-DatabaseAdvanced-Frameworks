package com.masdefect.io;

import com.masdefect.io.interfaces.FileIO;
import org.springframework.stereotype.Component;

import java.io.*;

@Component
public class FIleIOImpl implements FileIO {

    @Override
    public String read(String file) throws IOException {
        //impl
        return null;
    }

    @Override
    public void write(String fileContent, String file) throws IOException {
        //impl
    }
}
