package com.masdefect.controller;

import org.springframework.stereotype.Controller;

@Controller
public class PlanetsController {

    public String importDataFromJSON(String fileContent){
        //impl
        return null;
    }

    public String planetsWithNoPeopleTeleportedToThem(){
        return null;
    }
}
