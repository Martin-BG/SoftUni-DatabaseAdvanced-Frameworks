package com.masdefect.domain.dto.json;

import java.io.Serializable;

public class StarImportJSONDto implements Serializable {
    //impl
}
