package com.masdefect.domain.entities;

import java.io.Serializable;

public class Planet implements Serializable {
    //impl
}
