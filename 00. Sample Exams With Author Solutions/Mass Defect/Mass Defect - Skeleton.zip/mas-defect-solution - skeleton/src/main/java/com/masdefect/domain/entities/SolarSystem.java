package com.masdefect.domain.entities;

import java.io.Serializable;

public class SolarSystem implements Serializable {
    //impl
}
