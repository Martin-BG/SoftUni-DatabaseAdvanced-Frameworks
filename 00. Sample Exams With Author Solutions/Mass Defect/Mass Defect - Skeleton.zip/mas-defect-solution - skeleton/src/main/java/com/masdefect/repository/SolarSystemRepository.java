package com.masdefect.repository;

public interface SolarSystemRepository {

}
