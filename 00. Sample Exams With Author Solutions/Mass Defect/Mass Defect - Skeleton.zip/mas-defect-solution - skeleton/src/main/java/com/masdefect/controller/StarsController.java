package com.masdefect.controller;

import org.springframework.stereotype.Controller;

@Controller
public class StarsController {

    public String importDataFromJSON(String fileContent){
        //impl
        return null;
    }
}
