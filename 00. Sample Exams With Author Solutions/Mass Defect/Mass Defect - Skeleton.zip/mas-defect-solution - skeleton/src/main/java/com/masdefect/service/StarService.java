package com.masdefect.service;

import com.masdefect.domain.dto.json.StarImportJSONDto;

public interface StarService {

    void create(StarImportJSONDto starImportJSONDto);
}
