package com.masdefect.domain.entities;

import java.io.Serializable;

public class Star implements Serializable {
    //impl
}
