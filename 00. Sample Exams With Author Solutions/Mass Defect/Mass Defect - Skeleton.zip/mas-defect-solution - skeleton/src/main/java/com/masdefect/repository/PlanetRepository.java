package com.masdefect.repository;

public interface PlanetRepository {

}
