package com.masdefect.domain.entities;


import java.io.Serializable;

public class Person implements Serializable {
    //impl
}
