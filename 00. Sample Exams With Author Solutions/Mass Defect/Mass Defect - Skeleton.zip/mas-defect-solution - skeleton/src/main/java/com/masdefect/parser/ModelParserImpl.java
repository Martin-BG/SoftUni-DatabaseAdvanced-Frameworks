package com.masdefect.parser;

import com.masdefect.parser.interfaces.ModelParser;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class ModelParserImpl implements ModelParser {
    @Override
    public <S, D> D convert(S source, Class<D> destinationClass) {
        //impl
        return null;
    }

    @Override
    public <S, D> D convert(S source, Class<D> destinationClass, PropertyMap<S, D> propertyMap) {
        //impl
        return null;
    }
}
