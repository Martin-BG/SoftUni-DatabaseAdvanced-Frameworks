package com.masdefect.service;

import com.masdefect.domain.dto.json.SolarSystemImportJSONDto;

public interface SolarSystemService {

    void create(SolarSystemImportJSONDto solarSystemImportJSONDto);
}
