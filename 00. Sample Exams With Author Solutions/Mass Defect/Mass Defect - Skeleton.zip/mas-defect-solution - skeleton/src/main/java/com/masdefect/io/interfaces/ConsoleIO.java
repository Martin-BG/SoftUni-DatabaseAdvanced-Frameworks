package com.masdefect.io.interfaces;

public interface ConsoleIO {
    void write(String line);
}
