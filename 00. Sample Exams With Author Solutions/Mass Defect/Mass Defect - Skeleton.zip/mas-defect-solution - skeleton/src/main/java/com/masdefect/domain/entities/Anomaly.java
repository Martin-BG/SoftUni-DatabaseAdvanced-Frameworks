package com.masdefect.domain.entities;

import java.io.Serializable;
public class Anomaly implements Serializable {
    //impl
}
