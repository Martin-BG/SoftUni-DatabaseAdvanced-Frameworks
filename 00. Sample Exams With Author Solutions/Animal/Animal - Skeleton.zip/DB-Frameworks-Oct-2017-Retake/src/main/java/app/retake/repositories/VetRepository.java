package app.retake.repositories;

public interface VetRepository {
}
