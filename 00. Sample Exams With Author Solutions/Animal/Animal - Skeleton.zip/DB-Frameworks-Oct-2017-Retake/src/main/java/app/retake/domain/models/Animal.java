package app.retake.domain.models;

public class Animal {

}
