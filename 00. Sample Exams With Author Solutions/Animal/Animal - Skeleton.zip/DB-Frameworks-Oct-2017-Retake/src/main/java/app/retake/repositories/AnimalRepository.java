package app.retake.repositories;

public interface AnimalRepository {
}
