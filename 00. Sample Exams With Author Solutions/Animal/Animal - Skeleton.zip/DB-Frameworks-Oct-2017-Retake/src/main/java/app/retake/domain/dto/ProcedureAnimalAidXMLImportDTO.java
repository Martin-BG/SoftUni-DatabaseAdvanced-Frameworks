package app.retake.domain.dto;

public class ProcedureAnimalAidXMLImportDTO {

}
