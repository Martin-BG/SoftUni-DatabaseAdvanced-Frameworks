package app.retake.domain.models;

public class Procedure {
}
