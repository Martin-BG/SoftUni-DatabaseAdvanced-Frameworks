package app.retake.domain.models;

public class Vet {

}
