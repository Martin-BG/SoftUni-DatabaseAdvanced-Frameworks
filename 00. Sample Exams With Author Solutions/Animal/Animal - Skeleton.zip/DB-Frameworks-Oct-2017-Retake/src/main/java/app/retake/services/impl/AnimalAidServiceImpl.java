package app.retake.services.impl;


import app.retake.domain.dto.AnimalAidJSONImportDTO;
import app.retake.services.api.AnimalAidService;

public class AnimalAidServiceImpl implements AnimalAidService {

    @Override
    public void create(AnimalAidJSONImportDTO dto) {
    }
}
