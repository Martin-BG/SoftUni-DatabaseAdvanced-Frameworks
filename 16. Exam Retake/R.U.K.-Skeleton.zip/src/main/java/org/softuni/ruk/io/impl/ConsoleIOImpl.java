package org.softuni.ruk.io.impl;

import org.softuni.ruk.io.interfaces.ConsoleIO;

public class ConsoleIOImpl implements ConsoleIO {
    @Override
    public void write(String line) {
        //TODO: Implement me ...
        throw new UnsupportedOperationException("I am not implemented yet!");
    }
}
