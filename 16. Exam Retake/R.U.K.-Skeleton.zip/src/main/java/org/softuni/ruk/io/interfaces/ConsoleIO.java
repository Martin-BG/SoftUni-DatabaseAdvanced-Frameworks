package org.softuni.ruk.io.interfaces;

public interface ConsoleIO {
    void write(String line);
}
