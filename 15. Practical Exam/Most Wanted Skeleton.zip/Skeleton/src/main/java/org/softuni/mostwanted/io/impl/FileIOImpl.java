package org.softuni.mostwanted.io.impl;

import org.softuni.mostwanted.io.interfaces.FileIO;

import java.io.IOException;

public class FileIOImpl implements FileIO {
    @Override
    public String read(String file) throws IOException {
        //TODO: Implement me ...
        throw new UnsupportedOperationException("I am not implemented yet!");
    }

    @Override
    public void write(String fileContent, String file) throws IOException {
        //TODO: Implement me ...
        throw new UnsupportedOperationException("I am not implemented yet!");
    }
}
