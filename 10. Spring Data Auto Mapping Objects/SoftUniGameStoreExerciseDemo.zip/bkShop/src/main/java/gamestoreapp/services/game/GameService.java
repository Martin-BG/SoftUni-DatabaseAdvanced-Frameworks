package gamestoreapp.services.game;

public interface GameService {

    void test();
}