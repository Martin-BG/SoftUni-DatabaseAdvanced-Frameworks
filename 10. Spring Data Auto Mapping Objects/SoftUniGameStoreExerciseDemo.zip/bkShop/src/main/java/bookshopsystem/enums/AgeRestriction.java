package bookshopsystem.enums;

public enum AgeRestriction {

    MINOR, TEEN, ADULT
}
