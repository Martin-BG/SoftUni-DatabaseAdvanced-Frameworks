package bookshopsystem.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
